/**
 * Index-Based Keypoint Loader - FINALLY SIMPLE!
 * Uses pre-generated word-patterns.json to instantly find the right pattern
 */

let wordPatternsCache = null;

export const loadKeypointsForWord = async (word) => {
  console.log(`🔍 Loading keypoints for: "${word}"`);
  
  try {
    // Load the index file (once)
    if (!wordPatternsCache) {
      console.log('📋 Loading word patterns index...');
      const response = await fetch('/data/word-patterns.json');
      if (!response.ok) {
        throw new Error('Word patterns index not found. Run: node generate-word-index.js');
      }
      const indexData = await response.json();
      wordPatternsCache = indexData.patterns;
      console.log(`✅ Loaded patterns for ${Object.keys(wordPatternsCache).length} words`);
    }
    
    // Look up the pattern for this word
    const wordInfo = wordPatternsCache[word];
    if (!wordInfo) {
      throw new Error(`Word "${word}" not found in patterns index`);
    }
    
    const pattern = wordInfo.pattern;
    console.log(`✅ Found pattern for "${word}": ${pattern}`);
    
    // Load all files with this pattern
    const frames = await loadAllFilesWithPattern(word, pattern);
    
    if (frames.length === 0) {
      throw new Error(`No valid frames loaded for "${word}"`);
    }
    
    console.log(`✅ Loaded ${frames.length} frames for "${word}"`);
    return frames;

  } catch (error) {
    console.error(`❌ Error loading keypoints for "${word}":`, error);
    throw error;
  }
};

/**
 * Load all files with the known pattern
 */
const loadAllFilesWithPattern = async (word, pattern) => {
  const frames = [];
  let fileIndex = 0;
  let consecutiveErrors = 0;
  const maxErrors = 15;
  const maxFiles = 1000;
  
  console.log(`📊 Loading files with pattern: ${pattern}`);
  
  while (consecutiveErrors < maxErrors && fileIndex < maxFiles) {
    const frameNumber = String(fileIndex).padStart(12, '0');
    const filename = `${pattern}${frameNumber}_keypoints.json`;
    
    try {
      const response = await fetch(`/data/signs/${word}/${filename}`);
      
      if (response.ok) {
        const data = await response.json();
        const processedFrame = processOpenPoseFrame(data);
        
        if (hasValidKeypoints(processedFrame)) {
          frames.push(processedFrame);
        }
        
        consecutiveErrors = 0;
        
        // Progress logging
        if ((frames.length) % 50 === 0 && frames.length > 0) {
          console.log(`📈 Loaded ${frames.length} frames...`);
        }
      } else {
        consecutiveErrors++;
      }
    } catch (error) {
      consecutiveErrors++;
    }
    
    fileIndex++;
  }
  
  console.log(`✅ Final: ${frames.length} frames loaded`);
  return frames;
};

/**
 * Check if frame has valid keypoints
 */
const hasValidKeypoints = (frame) => {
  const hasValidPoints = (points) => {
    return points && points.some(point => point.confidence > 0.2);
  };
  
  return hasValidPoints(frame.pose) || 
         hasValidPoints(frame.leftHand) || 
         hasValidPoints(frame.rightHand) || 
         hasValidPoints(frame.face);
};

/**
 * Process OpenPose frame data
 */
const processOpenPoseFrame = (data) => {
  const processed = {
    pose: [],
    leftHand: [],
    rightHand: [],
    face: []
  };

  try {
    let person = null;

    if (data.people) {
      person = Array.isArray(data.people) ? data.people[0] : data.people;
    } else {
      person = data;
    }

    if (!person) return processed;

    // Extract keypoints
    if (person.pose_keypoints_3d) {
      processed.pose = extractKeypoints(person.pose_keypoints_3d, 4, true);
    } else if (person.pose_keypoints_2d) {
      processed.pose = extractKeypoints(person.pose_keypoints_2d, 3, false);
    }

    if (person.hand_left_keypoints_3d) {
      processed.leftHand = extractKeypoints(person.hand_left_keypoints_3d, 4, true);
    } else if (person.hand_left_keypoints_2d) {
      processed.leftHand = extractKeypoints(person.hand_left_keypoints_2d, 3, false);
    }

    if (person.hand_right_keypoints_3d) {
      processed.rightHand = extractKeypoints(person.hand_right_keypoints_3d, 4, true);
    } else if (person.hand_right_keypoints_2d) {
      processed.rightHand = extractKeypoints(person.hand_right_keypoints_2d, 3, false);
    }

    if (person.face_keypoints_3d) {
      processed.face = extractKeypoints(person.face_keypoints_3d, 4, true);
    } else if (person.face_keypoints_2d) {
      processed.face = extractKeypoints(person.face_keypoints_2d, 3, false);
    }

  } catch (error) {
    console.error('Error processing frame:', error);
  }

  return processed;
};

/**
 * Extract keypoints from flat array
 */
const extractKeypoints = (flatArray, stride, is3D) => {
  if (!flatArray || !Array.isArray(flatArray)) return [];

  const points = [];
  const confidenceThreshold = 0.2;

  for (let i = 0; i < flatArray.length; i += stride) {
    if (i + (stride - 1) >= flatArray.length) break;

    const confidence = flatArray[i + (stride - 1)];

    if (confidence > confidenceThreshold) {
      if (is3D) {
        points.push({
          x: flatArray[i] * 1.0,
          y: -flatArray[i + 1] * 1.0,
          z: -flatArray[i + 2] * 1.0,
          confidence: confidence
        });
      } else {
        const x = ((flatArray[i] - 960) / 960);
        const y = -(((flatArray[i + 1] - 540) / 540));
        points.push({
          x: x,
          y: y,
          z: 0,
          confidence: confidence
        });
      }
    } else {
      points.push({ x: 0, y: 0, z: 0, confidence: 0 });
    }
  }

  return points;
};

export default { loadKeypointsForWord };
